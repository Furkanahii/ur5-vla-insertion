# UR5 rijit pim-delik: en küçük çalışır örnek

Bu paket UR5, sabit pim tool'u, açık rijit delik, dış RGB kamera, betikli poz uzmanı ve bağımsız sonuç kontrolünü içerir. Sahne Python ile çalışma anında oluşturulur; ayrı kaydedilmiş tek bir sahne USD dosyası gerekmez. UR5'in kendisi NVIDIA'nın USD varlığından yüklenir.

**Kapsam:** Hazır VLA ağırlığı veya eğitim çalıştırmaz. Pim masadan kavranmaz; bileğe sabit bağlıdır. Uzman delik pozunu simülatörden bilir. Ham temas normal kuvvetleri saklanır; nicel kuvvet doğruluğu veya tam wrench kalibrasyonu yapılmış değildir.

## 1. Doğrulanmış sürüm ve referans

| Bileşen | Doğrulanmış değer |
| --- | --- |
| Isaac Lab / Isaac Sim | 2.3.0 / 5.1.0 |
| Çalıştırma | Singularity 4.3.2, amd64 NVIDIA container |
| Referans GPU / sürücü | Tesla T4 / 580.105.08 |
| Slurm kaynak isteği | 1 GPU, 4 CPU, 32 GiB RAM |
| Kontrol / fizik | 20 Hz / 120 Hz |
| Bölüm uzunluğu | 150 eylem, 151 gözlem, 7,5 saniye |
| Kamera | 640 x 480 RGB; sabit dış kamera |
| Pim çapı / delik çapı | 8 mm / 9,5 mm |
| Delik derinliği / hedef giriş | 25 mm / 20 mm |
| Kaynak sürüm | e93027a478e4c15d4cc030c79dc013e763410fa0 |
| Referans işleri | 2028002_0 aligned; 2028002_1 rim; 2028002_2 filled |

Container, kayan bir etikete göre değil şu digest ile tanımlıdır:

```text
docker://nvcr.io/nvidia/isaac-lab@sha256:f1eae1f847cc77e00738d919138d78dde9a12589da9a83b4909555a4abeddb20
```

Gönderilen çekirdek Python dosyaları ve manifest, üç başarılı doğrulama işinin kaynak SHA-256 kayıtlarıyla birebir eşleştirildi. `job.slurm`, çalışan projenin değiştirilmemiş iş betiğidir; paket aynı göreli klasör yapısını korur. Yeni arşivden temiz bir ortamda yeni GPU işi bu teslim hazırlanırken çalıştırılmadı. Aşağıdaki A40 isteği, alıcının A40 ortamında tekrar denemesi içindir; referans UR5 ölçümleri T4'e aittir. Isaac Sim 6.2.0 üzerinde uyumluluk henüz test edilmedi.

## 2. Paket içeriği

```text
rigid-insertion/
  run_insertion.py      # scene, controller, RGB/state/action recording
  scene_geometry.py    # fixed massive peg and open annulus collider
  task_math.py         # geometry, expert targets, measured success
  dataset_manifest.py  # task contract (also imported in single-run mode)
  pilot_manifest.json  # kept because the original launcher snapshots it
  check_insertion.py   # independent saved-result check
  job.slurm            # original, GPU-validated launcher
  test_task_math.py, test_manifest.py
ur5-pilot/
  episode.py           # synchronized episode schema / Cartesian delta helpers
  test_episode.py
reference/
  aligned_summary.json, rim_summary.json, filled_summary.json
  aligned_config.json, validated_source.sha256, provenance.json
  initial_rgb.png, final_rgb.png, gpu.csv, container.txt
```

Orijinal betikte çalışma zamanları şu konumlarda beklenir. Bunlar ZIP'e eklenmedi:

```text
ur5-pilot/.runtime/isaac-lab-2.3.0-amd64.sif
.runtime/env/bin/python
```

Host Python, simülasyonu çalıştırmak için kullanılmaz; simülasyon container'ın Python ortamındadır. Host Python yalnızca saf standart kütüphane kullanan bağımsız çıktı kontrolü içindir ve Python 3.10+ olmalıdır. Host üzerinde OpenVLA, PyTorch, TensorFlow veya eğitim verisi kurulması gerekmez.

## 3. Gerekli varlıklar ve eklentiler

UR5 USD giriş varlığı:

```text
https://omniverse-content-production.s3-us-west-2.amazonaws.com/Assets/Isaac/5.1/Isaac/Robots/UniversalRobots/ur5/ur5.usd
```

Bu USD'nin referans verdiği mesh/material dosyalarına da erişim gerekir. NVIDIA varlık kökü `https://omniverse-content-production.s3-us-west-2.amazonaws.com/Assets/Isaac/5.1` olarak kullanılır. İlk yüklemede hesaplama düğümünden gerekli HTTPS erişimi veya önceden hazırlanmış erişilebilir asset cache gerekir. Asset yükleme hatası, task başarısızlığıyla karıştırılmamalıdır.

Pim, adaptör, delik halkası, destekler ve fizik malzemesi kod içinde oluşturulur; ayrıca özel CAD/mesh paketi gerekmez. Kod UR5 bağlantı isimlerini bekler; Franka ile doğrudan aynı görev dosyası değildir.

Tam ve aynı container ile `AppLauncher` + `--headless --enable_cameras` kullanılır. Isaac Lab'in başsız kamera deneyimi, temel `isaaclab.python.headless` uygulaması üzerinde `omni.replicator.core`, `omni.kit.material.library` ve `omni.kit.viewport.rtx` bağımlılıklarını yükler. Fizik/USD, robot, diferansiyel IK, kamera ve temas sensörü bileşenleri bu dağıtım üzerinden kullanılır. Bu örnek için özel üçüncü taraf Kit eklentisi veya ROS bridge kurulmaz.

Sürüm sabit deneyim dosyası: https://github.com/isaac-sim/IsaacLab/blob/v2.3.0/apps/isaaclab.python.headless.rendering.kit

## 4. İlk hazırlık - mevcut imaj varsa yeniden indirmeyin

Arşivi hesabınızın yazılabilir scratch çalışma alanında açıp en üst klasöre geçin. İmaj indirme ve açma geçici dosyaları da scratch üzerinde tutulmalıdır:

```bash
cd UR5_Minimal_Ornek_2026-11-16
module load anaconda3/2025.06 singularity/4.3.2
mkdir -p .runtime ur5-pilot/.runtime
export SINGULARITY_CACHEDIR="$PWD/ur5-pilot/.runtime/singularity-cache"
export SINGULARITY_TMPDIR="$PWD/ur5-pilot/.runtime/singularity-tmp"
mkdir -p "$SINGULARITY_CACHEDIR" "$SINGULARITY_TMPDIR"
```

Saf Python 3.10+ ortamı için iki yöntemden biri seçilebilir. Hazır ortam varsa ona sembolik bağ verilebilir:

```bash
ln -s /ABSOLUTE/PATH/TO/PYTHON310_ENV .runtime/env
```

Ya da yeni, küçük bir ortam oluşturulabilir:

```bash
conda create --yes --prefix "$PWD/.runtime/env" --override-channels -c conda-forge python=3.10.14
```

Doğrulanmış SIF zaten varsa bu ada bağlayın:

```bash
ln -s /ABSOLUTE/PATH/TO/isaac-lab-2.3.0-amd64.sif ur5-pilot/.runtime/isaac-lab-2.3.0-amd64.sif
singularity sif list ur5-pilot/.runtime/isaac-lab-2.3.0-amd64.sif
```

Yoksa sabit digest'ten alınabilir; yaklaşık 8,34 GB SIF ve ek çalışma alanı gerekir:

```bash
singularity pull ur5-pilot/.runtime/isaac-lab-2.3.0-amd64.sif \
  docker://nvcr.io/nvidia/isaac-lab@sha256:f1eae1f847cc77e00738d919138d78dde9a12589da9a83b4909555a4abeddb20
```

## 5. A40 üzerinde tek hizalı örneği başlatma

NVIDIA lisansını kabul eden kullanıcı, betiğin beklediği ortam değişkenini ayarlar. Hesap/QoS adları farklıysa kaynak seçenekleri hesaba göre değiştirilir.

```bash
cd rigid-insertion
export ACCEPT_EULA=Y
sbatch --partition=ai --account=ai --qos=ai \
  --gres=gpu:ampere_a40:1 --export=ALL,ACCEPT_EULA=Y job.slurm aligned
```

T4 referansını eşlemek için aynı komutta `--gres=gpu:tesla_t4:1` kullanılır. Çalıştırma başsızdır; ilk tekrar üretim için masaüstü, VNC veya WebRTC gerekmez. Renderer yine RGB görüntü üretir.

Her iş kaynakları ayrı kopyalar, SHA-256 ve GPU bilgisi kaydeder. Kit cache, home, data ve log bağları oluşturulur; aynı cache `flock` ile sıraya alınır. Container'a `TERM=xterm` verilir. Bunlar özgün çalışan betikte korunmuştur.

## 6. Başarılı koşuda ne görülmeli?

Sarı pim, mavi delikli aparatın üzerinde hizalanır. İlk 1,5 saniyede hizalama, sonraki 5 saniyede aşağı iniş, son 1 saniyede bekleme görülür. Başlangıç hazırlığı bölümün dışındadır. Son durumda pim ucu yaklaşık 20 mm içeridedir. Sabit tool kullanılır; aktif kavrama yoktur.

Ölçülen başarı koşulları: son en az 10 kontrol adımı boyunca derinlik 18-25 mm, eksen eğimi en fazla 1 derece ve şaft kesiti/geometri payıyla deliğin içinde olmalıdır. Başarı, komut hedefinden değil ölçülen pim ucundan yeniden hesaplanır.

İş numarasını `IS_NO` yerine koyun:

```bash
sacct -j IS_NO --format=JobID,State,ExitCode,Elapsed
cat runs/IS_NO/summary.json
tail -n 30 insertion-IS_NO_*.log
```

Beklenen temel alanlar: `task_success=true`, `validation_passed=true`, `frame_count=150`, `observation_count=151`, `gravity_compensation_clipped_steps=0`. Günlükte bağımsız `INSERTION_VERIFIED: aligned, task_success=True` satırı olmalı. 151 PNG, GIF, ayrıntılı adım/geçiş JSONL'leri, metadata ve kamera kalibrasyonu `runs/IS_NO/` içinde oluşur.

Simülatör dosyaları yazdıktan sonra belgelenmiş hızlı kapanışı kullanır. Tek başına süreç çıkış kodu 0'a güvenilmez; betik host Python ile `check_insertion.py` çalıştırır. Checker başarısızsa Slurm işi de başarısız olur.

## 7. İsteğe bağlı üçlü fizik kontrolü

```bash
sbatch --partition=ai --account=ai --qos=ai \
  --gres=gpu:ampere_a40:1 --array=0-2%1 \
  --export=ALL,ACCEPT_EULA=Y job.slurm validation
```

0: açık delikte başarılı giriş. 1: pim bilerek kenara kayık, giriş engellenmeli. 2: delik kapalı, giriş engellenmeli. Engelli koşularda `task_success=false`, fakat beklenen engellenme ve temas işareti görüldüğünde `validation_passed=true` olur. Ham normal kuvvetleri kalibre edilmiş kuvvet doğruluğu olarak yorumlamayın.

## 8. Yerel CPU kontrolleri ve dosya bütünlüğü

Paket kökünde `sha256sum -c SHA256SUMS` (Mac: `shasum -a 256 -c SHA256SUMS`) kullanılabilir. Bu özetler gönderilen dosyaları denetler; `reference/validated_source.sha256` ise referans GPU işindeki çekirdek dosyaların kaydıdır.

```bash
cd rigid-insertion
PYTHONPATH=../ur5-pilot ../.runtime/env/bin/python -m unittest discover -s . -p 'test_*.py' -v
cd ../ur5-pilot
../.runtime/env/bin/python -m unittest discover -s . -p 'test_*.py' -v
```

Bu pakette 18 CPU testi bulunur. Simülasyonun yeniden çalıştığının kanıtı, alıcının yeni GPU koşusundan çıkan video/ölçümler ve bağımsız checker sonucu olacaktır. Tüm proje, eğitim verisi, model ağırlıkları, SSH erişimi veya kişisel rehber PDF'si bu paket için gerekli değildir ve eklenmemiştir.
